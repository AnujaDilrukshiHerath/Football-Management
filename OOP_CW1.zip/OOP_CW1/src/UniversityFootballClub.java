public class UniversityFootballClub{
    //inherits footballClub
    private String university; //name or the university which the club belongs to

    public UniversityFootballClub(String university) {
        this.university = university;
    }

    public String getUniversity() {
        return university;
    }

    public void setUniversity(String university) {
        this.university = university;
    }

}
